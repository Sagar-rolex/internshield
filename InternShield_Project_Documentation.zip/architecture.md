# Architecture
## InternShield AI

## 1. Principles
Preserve the existing repository, keep modules separate, treat user content and AI output as untrusted, retain deterministic findings, and enforce authorization on the backend.

## 2. High-Level Architecture

```text
React 19 + TanStack + Tailwind/shadcn
                 |
              HTTPS/API
                 |
             FastAPI
                 |
      +----------+-----------+
      |          |           |
  Validation   Auth/Roles  API routes
      |                      |
      +-----------+----------+
                  |
       +----------+-----------+
       |          |           |
   Rule Engine   OCR       Gemini service
   (6 signals) (images)     (optional)
       |          |           |
       +----------+-----------+
                  |
          Result aggregator
                  |
         SQLAlchemy / asyncpg
                  |
              PostgreSQL
```

Screenshot flow: image upload → server validation → OCR → extracted text → rule engine + optional Gemini → result aggregation → persistence.

## 3. Frontend Responsibilities
Authentication, protected navigation, manual/screenshot selection, validation, upload preview, status/error states, results, history, reports, and typed API calls. Never put Gemini secrets in browser code.

## 4. Backend Modules
Suggested logical modules; reuse existing equivalents rather than duplicating them:
- `api/routes/auth.py`
- `api/routes/analyses.py`
- `api/routes/reports.py`
- `api/routes/companies.py` (optional)
- `api/routes/admin.py`
- `services/rule_engine.py`
- `services/ocr_service.py`
- `services/gemini_service.py`
- `services/risk_aggregator.py`
- `core/config.py`
- `core/security.py`
- `db/session.py`
- `models/` and `schemas/`

## 5. Analysis Pipeline
1. Authenticate where required.
2. Validate request size and fields.
3. Run OCR for screenshot inputs.
4. Normalize text.
5. Run the existing six-signal rule engine.
6. Call Gemini only if configured and enabled.
7. Validate the AI response against a schema.
8. Aggregate results using a documented strategy.
9. Persist results with ownership information.
10. Return a typed result.

If OCR produces no useful text, show a clear error. If Gemini fails, return rule-only results when sufficient input exists. Never fabricate findings.

## 6. Scoring
Preserve existing rule weights and scoring unless a deliberate, tested change is approved. Keep `rule_score`, optional `ai_score`, and `final_score` distinct. Do not blindly average scores. Clamp to 0–100 and derive risk labels from one shared threshold definition. Do not call a heuristic score a probability without calibration.

## 7. Data Model
Inspect current models and migrations first. Possible entities: users/auth model, analyses, analysis findings, scam reports, optional companies, optional admin audit actions.

An analysis may store ID, owner ID, input type, job title, company, website, description/extracted text, rule score, optional AI score, final score, risk level, structured findings/recommendations, and timestamp.

Use migrations for schema changes; avoid duplicate tables.

## 8. API Contract Sketch
Adapt to current route conventions:
- `POST /api/analyze-job`
- `POST /api/analyze-screenshot`
- `GET /api/analyses`
- `GET /api/analyses/{id}`
- `POST /api/reports`
- `GET /api/reports/mine`
- `GET /api/admin/reports`
- `PATCH /api/admin/reports/{id}`

Every protected route must authenticate and authorize server-side.

## 9. Security
Load secrets from backend environment variables; keep `.env` ignored. Restrict CORS, validate requests, limit expensive endpoints, verify token signature and expiry, check ownership and admin roles, validate uploads, clean temporary files, and never log credentials. Treat Gemini output as untrusted.
