# Development Tasks
## InternShield AI

Treat this as a checklist. Inspect the repository before implementation; do not assume a feature is missing without checking.

## Phase 0 — Audit
- [ ] Inspect repository structure and stack.
- [ ] Identify exact six rule signals and weights.
- [ ] Review auth/token implementation and roles.
- [ ] Review database models and migrations.
- [ ] Run app and existing tests; record baseline failures.
- [ ] Confirm environment variable names without printing secret values.

**Acceptance:** Current architecture and known issues documented.

## Phase 1 — Authentication and Data Access
- [ ] Verify signup, login, logout, and session restoration.
- [ ] Verify password hashing, token signature, and expiry.
- [ ] Wait for session restoration before protected queries.
- [ ] Enforce backend admin role checks.
- [ ] Enforce record ownership for analyses and reports.
- [ ] Add safe errors and secret-free logs.

**Acceptance:** Users cannot access other users' data or admin endpoints.

## Phase 2 — Manual Analysis
- [ ] Keep Job Title and Company Name.
- [ ] Keep optional Website and Description.
- [ ] Remove salary, recruiter email, and work type as mandatory inputs.
- [ ] Validate inputs on client and server.
- [ ] Return typed results and persist history.

**Acceptance:** Manual analysis returns an explainable rule result.

## Phase 3 — Explainable Rules
- [ ] Document actual six signals and weights.
- [ ] Return findings and evidence snippets.
- [ ] Keep score deterministic.
- [ ] Share risk thresholds between API and UI.
- [ ] Test each signal, duplicates, and score boundaries.

**Acceptance:** Every contribution has an explanation and tests.

## Phase 4 — Screenshot/OCR
- [ ] Add Manual/Screenshot selector.
- [ ] Add drag/drop, browse, preview, remove, replace.
- [ ] Enforce JPG/JPEG/PNG and 5 MB in frontend and backend.
- [ ] Implement modular backend OCR.
- [ ] Display extracted text and data-quality notes.
- [ ] Handle OCR failure/empty output safely.
- [ ] Clean temporary files.

**Acceptance:** Valid screenshots are analyzed; invalid/unreadable images get clear errors.

## Phase 5 — Gemini (Optional)
- [ ] Store `GEMINI_API_KEY` in backend environment configuration.
- [ ] Ensure `.env` is in `.gitignore`.
- [ ] Add/reuse modular Gemini service.
- [ ] Bound input and validate structured response.
- [ ] Keep AI and rule findings separate.
- [ ] Document/test score aggregation.
- [ ] Preserve rule-only fallback.
- [ ] Add timeout/error handling.

**Acceptance:** AI augments analysis but is not required for baseline detection.

## Phase 6 — History and Reports
- [ ] Add paginated current-user history.
- [ ] Add analysis detail view.
- [ ] Add report categories and submission.
- [ ] Add report status tracking.
- [ ] Restrict users to their own records.
- [ ] Add admin review endpoints/UI.

**Acceptance:** Persistence and authorization work correctly.

## Phase 7 — Company Profiles (Optional)
- [ ] Add company search/profile.
- [ ] Add verification workflow.
- [ ] Distinguish verified facts from user allegations.
- [ ] Restrict status changes to admins.
- [ ] Record admin decisions if practical.

**Acceptance:** Company status is authorized and traceable.

## Phase 8 — Safety Report Export (Optional)
- [ ] Generate printable/downloadable report from saved analysis.
- [ ] Include score, evidence, findings, recommendations, date, disclaimer.
- [ ] Exclude secrets and unnecessary personal data.
- [ ] Preserve the saved historical result.

**Acceptance:** Export matches the stored analysis.

## Phase 9 — Security
- [ ] Validate request sizes and text lengths.
- [ ] Restrict CORS.
- [ ] Rate-limit expensive endpoints where practical.
- [ ] Validate upload content, not just extension.
- [ ] Verify token expiry and admin roles.
- [ ] Use SQLAlchemy safely.
- [ ] Ensure logs exclude secrets and tokens.

**Acceptance:** Security checks pass and no secrets are exposed.

## Phase 10 — Tests and UI Polish
- [ ] Add pytest tests for rules, APIs, auth, OCR, permissions.
- [ ] Add frontend tests for forms, upload states, and results.
- [ ] Test desktop, tablet, and mobile.
- [ ] Add loading, empty, partial-success, and error states.
- [ ] Check keyboard navigation and focus.
- [ ] Run lint, format, type checks, and tests.

**Acceptance:** Core flows pass and UI is responsive.

## Phase 11 — Deployment
- [ ] Configure production environment variables.
- [ ] Configure HTTPS, CORS, database URL, allowed origins.
- [ ] Apply migrations.
- [ ] Verify health endpoint.
- [ ] Test auth, manual analysis, screenshot analysis, history, and admin restrictions.
- [ ] Confirm no secrets are committed.

**Acceptance:** Deployed app works end-to-end without secret exposure.
