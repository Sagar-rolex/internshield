# Project Memory
## InternShield AI — Fake Internship & Job Scam Detector

Read this before future coding sessions. This is the project context to preserve.

## Source-of-Truth Stack
- Frontend: React 19 + TanStack Start/Router/Query
- UI: Tailwind CSS v4 + shadcn/ui
- Backend: Python FastAPI
- ORM: SQLAlchemy
- Database: PostgreSQL via asyncpg
- Authentication: scrypt password hashing + HMAC bearer tokens, as currently implemented
- Detection: six weighted deterministic heuristic signals
- Tooling: Vite 7, TypeScript 5.8, ESLint, Prettier, Uvicorn
- Optional AI: Gemini called only from backend
- OCR: modular backend service such as Tesseract

Do not revert to React + Express + Supabase assumptions unless the repository has explicitly changed.

## Product Goal
Help students/job seekers assess suspicious job and internship postings, explain warning signs, and recommend safer next steps.

## Analysis UX
Two modes:

**Manual:** Job Title, Company Name, optional Company Website, optional Job Description. Do not require salary/stipend, recruiter email, or work type.

**Screenshot:** JPG/JPEG/PNG, maximum 5 MB, preview/remove/replace, backend OCR, display extracted text, run extracted text through the rule engine and optional Gemini.

## Detection
- Preserve the existing six weighted deterministic signals.
- Inspect source to find actual signal names and weights; do not invent or silently replace them.
- Keep rule findings separate from Gemini findings.
- Rule-only analysis must work when Gemini is unavailable.
- Ground evidence in supplied text.
- Use shared Low/Medium/High thresholds.
- Do not describe a heuristic score as a true probability unless calibrated on labeled data.
- Do not claim certainty from rules or AI alone.

## Authentication and Authorization
- Preserve current auth unless a demonstrated issue requires change.
- Validate HMAC token signature and expiry on the backend.
- Enforce admin role checks on backend routes.
- Users may access only their own analyses and reports.
- Never trust a role supplied by the frontend.
- Never log passwords, tokens, or API keys.

## Gemini Secrets
Environment variable: `GEMINI_API_KEY`
- Backend only; never in React code.
- Keep `.env` in `.gitignore`.
- Never hardcode, commit, return, or log secrets.
- If a key is exposed, revoke it and create a replacement.

## Database
Use PostgreSQL, SQLAlchemy, and existing migrations. Inspect current models before creating tables. Avoid duplicate schemas and destructive changes. Store owner ID, input type, result/findings, and timestamp according to the existing schema.

## UI/UX
Preserve the current design system. Reuse Tailwind v4 and shadcn/ui. Keep the flow simple; show loading/error/empty/partial-success states; explain findings; use text labels as well as colors; optimize screenshot analysis for mobile.

## Coding Assistant Rules
Before changes:
1. Inspect the repository and current implementation.
2. Identify the actual root cause before bug fixes.
3. Reuse existing modules and dependencies.
4. Make incremental, testable changes.
5. Preserve working authentication and dashboards.
6. Add/update tests.
7. Summarize files changed, migrations, environment variables, and test commands.
8. Never claim a feature is implemented unless it is implemented and verified.

## Recommended Order
1. Audit and stabilize auth/data access.
2. Manual analysis.
3. Explainable six-signal engine.
4. Screenshot/OCR.
5. Optional Gemini integration.
6. History and reports.
7. Company profiles.
8. Safety report export.
9. Security hardening.
10. Tests, polish, deployment.
