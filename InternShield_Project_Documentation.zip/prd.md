# Product Requirements Document (PRD)
## InternShield AI — Fake Internship & Job Scam Detector

**Status:** Initial specification | **Project:** College/MCA project

## 1. Overview
InternShield AI helps students and job seekers assess suspicious job and internship postings. Users can enter details manually or upload a screenshot. The system analyzes available evidence using a deterministic six-signal rule engine and, when configured, an external Gemini model for contextual analysis. It returns an explainable risk assessment and practical safety recommendations.

## 2. Problem and Goals
Students encounter upfront-fee requests, fake recruiters, misleading compensation, impersonated companies, suspicious links, and requests for sensitive information. The product aims to make assessment easy, explain the evidence behind each result, support screenshots, preserve a rule-based baseline, and provide history/reporting tools.

## 3. Target Users
- College students and fresh graduates
- Internship seekers and entry-level job seekers
- Administrators reviewing reports and company records

## 4. Technology Baseline
- Frontend: React 19, TanStack Start/Router/Query
- UI: Tailwind CSS v4, shadcn/ui
- Backend: Python FastAPI
- ORM/database: SQLAlchemy, PostgreSQL via asyncpg
- Authentication: scrypt passwords and HMAC bearer tokens, as currently implemented
- Detection: six weighted deterministic heuristic signals
- Optional AI: Gemini API called only from the backend
- OCR: modular backend service, such as Tesseract
- Tooling: Vite 7, TypeScript 5.8, ESLint, Prettier, Uvicorn

**Compatibility:** Inspect the repository before changing dependencies. Do not reintroduce Express or Supabase assumptions unless the actual repository uses them.

## 5. Functional Requirements

### Authentication
- Signup, login, logout, session restoration.
- Stable user ID for owned records.
- Backend-enforced admin authorization.
- Clear errors without leaking internal details.

### Manual Analysis
Fields: Job Title (required), Company Name (required), Website (optional), Description (optional when sufficient information exists). Do not require salary, recruiter email, or work type.

### Screenshot Analysis
- JPG/JPEG/PNG, maximum 5 MB.
- Preview, filename, size, remove and replace.
- Backend OCR; show extracted text.
- Handle invalid files, unreadable images, and OCR errors.
- Validate file content and size server-side.

### Detection
- Run the existing six-signal deterministic engine.
- Return triggered signals, evidence, score contributions, and explanations.
- If Gemini is configured, call it only through FastAPI.
- Gemini failure must not break rule-based analysis.
- Keep rule findings and AI findings distinct.

### Results
Display risk score (0–100), risk level (Low/Medium/High), findings, evidence snippets, explanations, safety recommendations, and OCR text for screenshot input. Show confidence only if it has a documented method. Include a disclaimer that results are assessments, not guarantees.

### History and Reports
- Users can view only their own analyses and submitted reports.
- Users can submit reports with category, description, and optional evidence.
- Admins can review reports and update status.
- Enforce ownership and roles on every backend endpoint.

### Optional Enhancements
- Company profiles with Verified / Needs Verification / Reported / High Risk statuses. Unreviewed reports must not be presented as proven facts.
- Printable/downloadable safety report based on a saved analysis.

## 6. Risk Labels
Default thresholds if consistent with current code: 0–30 Low, 31–60 Medium, 61–100 High. Use one shared threshold definition. A heuristic score is not a calibrated probability unless validated on representative labeled data.

## 7. Non-functional Requirements
- Responsive and accessible UI.
- Server-side validation and safe upload handling.
- Secrets never appear in frontend bundles or version control.
- Secure password hashing and token expiry/validation.
- Parameterized database access through SQLAlchemy.
- Clear loading, empty, success, partial-success, and error states.
- Tests for rules, authentication, ownership, OCR, and APIs.
- Logs must exclude passwords, tokens, API keys, and unnecessary personal data.

## 8. Acceptance Criteria
- Users can sign up and log in.
- Manual analysis returns an explainable assessment.
- Valid screenshots produce OCR text and an assessment.
- Rule-based analysis works without Gemini.
- Gemini errors fall back gracefully when possible.
- Users cannot access other users' records.
- Normal users cannot access admin operations.
- Core tests pass.
