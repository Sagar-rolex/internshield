# Design System
## InternShield AI

## 1. Design Goal
Professional, clear, security-aware, and approachable for students. Prioritize hierarchy and explanations over excessive animation.

## 2. Preserve Existing UI
Inspect the current app first. Reuse Tailwind v4, shadcn/ui, existing tokens, components, and layout. Do not redesign unrelated pages.

## 3. Analyze Page
Heading: **Analyze Job Posting**
Prompt: “How would you like to analyze the job?”

Two selectable cards:
- **Enter Job Details** — manually provide posting information.
- **Upload Screenshot** — extract and analyze text from a job-posting image.

Show only the selected form.

### Manual
- Job Title *
- Company Name *
- Company Website (optional)
- Job Description (optional when enough information exists)

Do not require salary/stipend, recruiter email, or work type.

### Screenshot
- Drag/drop and browse
- JPG/JPEG/PNG, maximum 5 MB
- Preview, filename, size
- Remove/replace controls
- Analyze Screenshot button

## 4. Analysis States
Idle, selected file, validating, uploading, extracting text, rule analysis, optional AI analysis, complete, partial result, and error. Reflect actual backend status; do not fake progress or claim a step finished prematurely.

## 5. Result Hierarchy
1. Risk score and Low/Medium/High label
2. Summary
3. Evidence/red flags
4. Rule-based findings
5. AI findings if available
6. Safety recommendations
7. Extracted text and original screenshot when relevant
8. Disclaimer

Use “Risk Score” instead of “Scam Probability” unless probability calibration has been validated. Distinguish rule and AI findings.

## 6. Visual Semantics
- Low: green
- Medium: amber
- High: red

Always include a text label/icon; do not rely on color alone.

## 7. Dashboard and History
Possible cards: Total Analyses, High-Risk Analyses, Reports Submitted, Recent Activity. Use real database data; show empty states instead of fake sample numbers. History should show title, company, input type, score, risk label, and date. Enforce per-user visibility.

## 8. Reports and Companies
Explain that user reports are allegations until reviewed. Company statuses should clearly distinguish verified information from reported claims.

## 9. Responsive and Accessible
- Desktop: method cards side by side.
- Mobile: stacked cards and full-width actions.
- Keyboard-operable controls and visible focus.
- Explicit labels, readable contrast, semantic headings.
- Screen-reader status announcements for upload/analysis.
- Avoid horizontal scrolling.

## 10. Error/Empty Copy
- “We couldn't extract readable text. Try a clearer screenshot.”
- “AI analysis is unavailable right now. Rule-based findings are shown.”
- “No analyses yet. Analyze a job posting to see your history here.”
- “No reports match these filters.”

Never expose stack traces, SQL errors, API keys, or tokens in user-facing messages.
