# Detection Rules
## InternShield AI

## 1. Purpose
The detector provides a risk assessment, not a definitive legal or factual judgment. The initial engine has six weighted deterministic signals. Inspect source code and document the exact current names and weights; do not silently replace them based on this document.

## 2. Risk Labels
Use current thresholds if already implemented. Suggested defaults: 0–30 Low, 31–60 Medium, 61–100 High. Share one threshold implementation across API and UI. Clamp scores to 0–100. Do not call the score a calibrated probability without validation.

## 3. Six Signals
Document each existing signal with stable ID, name, weight, trigger conditions, evidence extraction, user explanation, tests, and false-positive notes.

Potential categories to map to the existing six signals:
1. Upfront payment or registration fee
2. Urgency or pressure tactics
3. Unrealistic compensation or guaranteed outcomes
4. Suspicious communication/contact method
5. Suspicious URL/domain
6. Missing, inconsistent, or unverifiable company/recruiter details

These are candidate categories, not claims about the current implementation. Preserve actual signal behavior unless a tested change is approved.

## 4. Evidence
- Attach a specific evidence snippet when available.
- Never invent evidence.
- Normalize case/whitespace for matching but preserve original text for display.
- Distinguish missing information from suspicious information.
- A missing website, free email domain, URL shortener, or high salary alone does not prove fraud.
- Avoid double-counting multiple phrases for the same underlying event.

## 5. Deterministic Scoring
Same input and configuration should produce the same rule score. Document signal weights, stacking, duplicate handling, score cap, and label thresholds. Add tests for each rule and boundary values.

## 6. Optional Gemini Layer
- Call only from FastAPI.
- Read `GEMINI_API_KEY` from backend environment variables.
- Limit input and avoid unnecessary personal data.
- Request structured findings grounded in supplied text.
- Validate response schema and score bounds.
- Treat AI output as untrusted.
- Do not invent external verification facts.
- Keep AI findings separate from rule findings.
- If Gemini fails, preserve rule-only analysis.
- Document/test any score aggregation; do not blindly average scores.

## 7. Confidence
Do not trust a model's self-reported confidence as calibrated truth. If confidence is shown, calculate it with a documented method based on input completeness, OCR quality, and evidence consistency. Otherwise show data-quality notes instead.

## 8. OCR and Uploads
Accept JPG/JPEG/PNG, max 5 MB. Validate server-side, including file content. OCR text is untrusted. Empty/low-quality OCR must produce a clear message. Do not fabricate missing text.

## 9. Recommendations
Recommend independently verifying the company and vacancy, avoiding upfront payments without verification, never sharing OTP/PIN/password/banking credentials, resisting pressure tactics, and avoiding suspicious links.

## 10. Suggested Structured Result
Adapt names to current schemas:

```json
{
  "rule_score": 0,
  "ai_score": null,
  "final_score": 0,
  "risk_level": "Low",
  "findings": [
    {
      "signal_id": "example",
      "severity": "low",
      "evidence": "exact text from posting",
      "explanation": "why this evidence matters",
      "source": "rule"
    }
  ],
  "recommendations": [],
  "data_quality_notes": []
}
```
